# 🎯 Smart Interview Preparation Tracker

A full-stack web application to track job applications, interview rounds, and measure preparation readiness across technical domains.

---

## 🏗️ Architecture Overview

```
interview-tracker/
├── backend/                          # Spring Boot REST API
│   └── src/main/java/com/tracker/
│       ├── model/                    # JPA Entities
│       │   ├── User.java
│       │   ├── JobApplication.java
│       │   ├── InterviewRound.java
│       │   └── TopicProgress.java
│       ├── repository/               # Spring Data JPA Repos
│       │   ├── UserRepository.java
│       │   ├── JobApplicationRepository.java
│       │   ├── InterviewRoundRepository.java
│       │   └── TopicProgressRepository.java
│       ├── service/                  # Business Logic
│       │   ├── AuthService.java
│       │   ├── JobApplicationService.java
│       │   └── ReadinessScoreService.java  ← CORE ALGORITHM
│       ├── controller/               # REST Endpoints
│       │   ├── AuthController.java
│       │   ├── JobApplicationController.java
│       │   └── DashboardController.java
│       ├── config/                   # Security + JWT
│       │   ├── SecurityConfig.java
│       │   ├── JwtUtil.java
│       │   └── JwtAuthFilter.java
│       ├── dto/                      # Request/Response DTOs
│       │   ├── AppDTOs.java
│       │   └── ReadinessScoreDTO.java
│       └── exception/                # Error Handling
│           ├── ApiException.java
│           └── GlobalExceptionHandler.java
└── frontend/                        # React + Tailwind CSS
    └── src/
        ├── App.jsx                  # Main Dashboard
        ├── components/
        │   ├── StatCard.jsx
        │   ├── ScoreRing.jsx
        │   ├── ProgressBar.jsx
        │   └── StatusBadge.jsx
        └── api/
            └── client.js            # Axios API calls
```

---

## 🧠 Readiness Score Algorithm

```
ReadinessScore = Σ (domainScore × weightage / 100)

Domain Weights:
  ┌──────────────────────────────┬──────────┐
  │ DSA                          │   40%    │
  │ System Design                │   35%    │
  │ Core Java & CS Fundamentals  │   25%    │
  └──────────────────────────────┴──────────┘

domainScore = average(confidenceScore of all topics in domain)

Score Levels:
  85-100 → INTERVIEW_READY  🟢
  70-84  → STRONG           🔵
  50-69  → MODERATE         🟡
  30-49  → DEVELOPING       🟠
  0-29   → BEGINNER         🔴
```

---

## 🔌 REST API Reference

### Auth
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /api/auth/register | Register new user |
| POST | /api/auth/login | Login, returns JWT |

### Job Applications
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /api/applications | Get all applications |
| POST | /api/applications | Create application |
| PUT | /api/applications/{id} | Update application |
| DELETE | /api/applications/{id} | Delete application |
| GET | /api/applications/search?keyword= | Search applications |

### Dashboard
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /api/dashboard | Full dashboard stats |
| GET | /api/dashboard/readiness | Readiness score only |

### Topic Progress
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /api/topics | Get all topics |
| POST | /api/topics | Add topic with score |
| PUT | /api/topics/{id} | Update confidence score |

---

## 🗄️ Database Schema (ERD Summary)

```
users (id, fullName, email, password, createdAt)
  │
  ├── job_applications (id, companyName, jobRole, status, location,
  │       salaryRange, appliedDate, jobType, notes, user_id)
  │         │
  │         └── interview_rounds (id, roundType, roundNumber, scheduledAt,
  │                 interviewerName, platform, outcome, feedback, job_application_id)
  │
  └── topic_progress (id, topicName, domain, confidenceScore, status,
          practiceProblems, solvedProblems, notes, resourceUrl, user_id)
```

---

## 🚀 Quick Start

### Backend
```bash
# Prerequisites: Java 17, Maven, MySQL
git clone <repo>
cd backend

# Update application.properties with your MySQL credentials
mvn spring-boot:run
# Server runs on http://localhost:8080
```

### Frontend
```bash
cd frontend
npx create-react-app . --template typescript
npm install recharts axios tailwindcss
npm start
# App runs on http://localhost:3000
```

### Docker (Full Stack)
```bash
docker-compose up --build
```

---

## 📊 Features

- ✅ Track 100+ job applications with status pipeline (Wishlist → Offer)
- ✅ Log interview rounds per application (DSA, System Design, HR, etc.)
- ✅ Readiness score engine with weighted domain calculation
- ✅ Weak area identification (topics < 50% confidence)
- ✅ Visual dashboard: Pie chart, Radar chart, Bar chart
- ✅ JWT-secured REST API
- ✅ Search & filter applications
- ✅ Upcoming interview schedule

---

## 🛠️ Tech Stack

| Layer | Technology |
|-------|-----------|
| Backend | Spring Boot 3.2 + Spring Security + Spring Data JPA |
| Database | MySQL 8.0 |
| Auth | JWT (jjwt 0.11.5) + BCrypt |
| Frontend | React 18 + Tailwind CSS |
| Charts | Recharts |
| Build | Maven |
